# StageWave Studio — Native Android starter

This Android Studio project starts the native Kotlin/Jetpack Compose app and MIDI device discovery UI.

## Important
This is an early scaffold, **not a complete playable instrument and not ready for Play Store release**. The current MIDI screen discovers devices but does not yet connect note events to a synth. Mixer and ambient-pad controls are UI prototypes. SF2 playback, native audio processing, SoundFont import, effects, preset persistence, and live-performance testing remain to be implemented.

## Open
1. Download and unzip the project on a computer.
2. Install Android Studio and Android SDK tools.
3. Open this folder in Android Studio and allow Gradle sync.
4. Run on a supported Android device.
5. Connect a USB MIDI keyboard with a compatible OTG adapter to test device discovery.

Package ID: `com.stagewave.studio`
Minimum SDK: 26
Configured target SDK: 35 (verify current Google Play requirements before release).

## Next engineering phase
Integrate FluidSynth as a native Android library, add SoundFont import via Android's file picker, route MIDI note-on/off and sustain to FluidSynth, then implement a real mixer and DSP effects. Test latency and stability on real phones before producing a signed Android App Bundle.

References:
- Android MIDI: https://developer.android.com/reference/android/media/midi/package-summary
- Oboe audio: https://developer.android.com/games/sdk/oboe
- FluidSynth: https://www.fluidsynth.org/documentation/
