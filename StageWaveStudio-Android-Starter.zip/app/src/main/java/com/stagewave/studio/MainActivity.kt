package com.stagewave.studio

import android.content.Context
import android.media.midi.MidiDeviceInfo
import android.media.midi.MidiManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Ink = Color(0xFF0A0E18)
private val Panel = Color(0xFF151C2C)
private val Mint = Color(0xFF54E0C0)
private val Soft = Color(0xFFA6B1C8)

class MainActivity : ComponentActivity() {
    private var midiManager: MidiManager? = null
    private val deviceNames = mutableStateListOf<String>()
    private val midiStatus = mutableStateOf("Checking MIDI devices…")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        midiManager = getSystemService(Context.MIDI_SERVICE) as? MidiManager
        refreshMidi()
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(primary=Mint, background=Ink, surface=Panel, onBackground=Color.White, onSurface=Color.White)) {
                StageWaveScreen(midiStatus.value, deviceNames.toList(), { refreshMidi() })
            }
        }
    }

    private fun refreshMidi() {
        deviceNames.clear()
        val manager = midiManager
        if (manager == null) {
            midiStatus.value = "MIDI API is unavailable on this device"
            return
        }
        manager.devices.forEach { info ->
            val name = info.properties.getString(MidiDeviceInfo.PROPERTY_NAME) ?: "MIDI device ${info.id}"
            deviceNames.add("$name • ID ${info.id}")
        }
        midiStatus.value = if (deviceNames.isEmpty()) "No MIDI devices detected yet" else "${deviceNames.size} MIDI device(s) detected"
    }
}

@Composable
private fun StageWaveScreen(status: String, devices: List<String>, onRefresh: () -> Unit) {
    var tab by remember { mutableStateOf("Performance") }
    var master by remember { mutableFloatStateOf(.8f) }
    var pad by remember { mutableFloatStateOf(.55f) }
    var reverb by remember { mutableFloatStateOf(.35f) }
    var delay by remember { mutableFloatStateOf(.2f) }

    Column(Modifier.fillMaxSize().background(Ink).padding(18.dp), verticalArrangement=Arrangement.spacedBy(14.dp)) {
        Row(verticalAlignment=Alignment.CenterVertically, horizontalArrangement=Arrangement.SpaceBetween, modifier=Modifier.fillMaxWidth()) {
            Column {
                Text("STAGEWAVE", color=Mint, fontSize=12.sp, fontWeight=FontWeight.Bold, letterSpacing=3.sp)
                Text("Studio", color=Color.White, fontSize=32.sp, fontWeight=FontWeight.ExtraBold)
                Text("NATIVE ANDROID • STARTER BUILD", color=Soft, fontSize=10.sp, letterSpacing=1.sp)
            }
            Surface(color=Mint.copy(alpha=.12f), shape=RoundedCornerShape(16.dp)) {
                Text("SW", Modifier.padding(14.dp), color=Mint, fontWeight=FontWeight.ExtraBold, fontSize=20.sp)
            }
        }
        Row(horizontalArrangement=Arrangement.spacedBy(8.dp), modifier=Modifier.fillMaxWidth()) {
            listOf("Performance","Mixer","Pads").forEach { name ->
                Button(onClick={tab=name}, modifier=Modifier.weight(1f), colors=ButtonDefaults.buttonColors(containerColor=if(tab==name) Mint else Panel, contentColor=if(tab==name) Ink else Color.White)) { Text(name, fontSize=12.sp) }
            }
        }
        Card(colors=CardDefaults.cardColors(containerColor=Panel), shape=RoundedCornerShape(18.dp)) {
            Column(Modifier.padding(16.dp), verticalArrangement=Arrangement.spacedBy(8.dp)) {
                Text("MIDI CONNECTION", color=Mint, fontWeight=FontWeight.Bold, letterSpacing=1.sp)
                Text(status, color=Color.White)
                if(devices.isEmpty()) Text("Connect a compatible USB MIDI keyboard using an OTG adapter, then refresh.", color=Soft, fontSize=12.sp)
                devices.forEach { Text(it, color=Soft, fontSize=12.sp) }
                OutlinedButton(onClick=onRefresh) { Text("Refresh MIDI devices") }
                Text("Device discovery foundation only: live note routing is a next development step.", color=Soft, fontSize=11.sp)
            }
        }
        Card(colors=CardDefaults.cardColors(containerColor=Panel), shape=RoundedCornerShape(18.dp), modifier=Modifier.weight(1f)) {
            Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement=Arrangement.spacedBy(12.dp)) {
                when(tab) {
                    "Mixer" -> {
                        Text("MASTER MIXER", color=Mint, fontWeight=FontWeight.Bold)
                        ControlSlider("Master volume", master, { master=it })
                        Text("Per-instrument channels and effects routing are planned.", color=Soft, fontSize=12.sp)
                    }
                    "Pads" -> {
                        Text("AMBIENT PADS", color=Mint, fontWeight=FontWeight.Bold)
                        ControlSlider("Pad level", pad, { pad=it })
                        ControlSlider("Reverb", reverb, { reverb=it })
                        ControlSlider("Delay", delay, { delay=it })
                        Text("UI prototype only; controls are not yet connected to an audio DSP engine.", color=Soft, fontSize=12.sp)
                    }
                    else -> {
                        Text("LIVE PERFORMANCE", color=Mint, fontWeight=FontWeight.Bold, letterSpacing=1.sp)
                        Text("Grand Piano", color=Color.White, fontSize=24.sp, fontWeight=FontWeight.Bold)
                        Text("SF2 engine: integration pending", color=Soft, fontSize=12.sp)
                        Text("MIDI input • SoundFont library • layered instruments • performance presets", color=Soft, fontSize=13.sp)
                        ControlSlider("Master volume", master, { master=it })
                    }
                }
            }
        }
        Text("NEXT: FluidSynth SF2 playback → MIDI note routing → real mixer/effects → device testing → signed Play Store bundle", color=Soft, fontSize=11.sp)
    }
}

@Composable
private fun ControlSlider(label: String, value: Float, onChange: (Float)->Unit) {
    Column {
        Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.SpaceBetween) {
            Text(label, color=Color.White, fontSize=13.sp)
            Text("${(value*100).toInt()}%", color=Mint, fontSize=12.sp)
        }
        Slider(value=value, onValueChange=onChange)
    }
}
